
options={
	ip = "192.168.0.201",
	port = 9901,
	lasernum = 32,
	x_angle = 0.542,
	y_angle = 0.7253,
	z_angle = -151.5746,
	x_offset = -0.6227,
	y_offset = 1.4020,
	z_offset = 2.0810,
	
}
return options
