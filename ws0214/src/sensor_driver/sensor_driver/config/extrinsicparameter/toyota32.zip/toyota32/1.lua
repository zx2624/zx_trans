
options={
	ip = "192.168.0.202",
	port = 9902,
	lasernum = 32,
	x_angle = -0.5,
	y_angle = 0,
	z_angle = -90.6,	
	x_offset = 0.623,
	y_offset = 1.4,
	z_offset = 2.1,

}
return options
