
"use strict";

let RadarDetection = require('./RadarDetection.js');

module.exports = {
  RadarDetection: RadarDetection,
};
