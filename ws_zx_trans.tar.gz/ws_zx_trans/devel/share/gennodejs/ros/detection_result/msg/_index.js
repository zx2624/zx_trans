
"use strict";

let detection_result_msg = require('./detection_result_msg.js');

module.exports = {
  detection_result_msg: detection_result_msg,
};
