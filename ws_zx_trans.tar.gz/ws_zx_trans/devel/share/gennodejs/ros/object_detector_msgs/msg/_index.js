
"use strict";

let laser_electronic_result = require('./laser_electronic_result.js');

module.exports = {
  laser_electronic_result: laser_electronic_result,
};
