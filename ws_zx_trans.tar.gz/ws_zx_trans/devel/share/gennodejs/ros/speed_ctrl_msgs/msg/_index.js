
"use strict";

let speed_ctrl = require('./speed_ctrl.js');

module.exports = {
  speed_ctrl: speed_ctrl,
};
