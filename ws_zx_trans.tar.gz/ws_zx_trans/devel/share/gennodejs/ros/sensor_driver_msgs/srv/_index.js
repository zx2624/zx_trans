
"use strict";

let startconfig = require('./startconfig.js')

module.exports = {
  startconfig: startconfig,
};
